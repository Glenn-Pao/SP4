--[[
Use these values to initialise the player variables
]]--

movementSpeed = 5.0
animationCounter = 0.0
animationDirection = 1
animationSpeed = 0.1
animationMaxCounter = 8
leftCollision = 0.25
rightCollision = 0.75
topCollision = 0.8
bottomCollision = 0.1
