showFPS = 0
fullscreen = 0
colored = 1
