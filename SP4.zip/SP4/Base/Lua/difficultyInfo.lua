--[[
Use these values to initialise the difficulty variables
]]--

currentDifficultyUnlocked = 0
