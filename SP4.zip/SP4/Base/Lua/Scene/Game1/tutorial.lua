--[[
Use these values to initialise the scene variables
]]--

tileSize = 50

script0 = "Use \"WASD\" to move around."
script1 = "Timer is running while you are in the maze."
script2 = "Try to find the exit before the timer run out of time."
script3 = "Choose your path carefully."
script4 = "Congratulations! You have found the exit."
script5 = "Opps! A deadend..."

scriptTimeUp = "Sorry, Time up!"
scriptFinished = "Tutorial completed!"
scriptExit = "<Click anywhere to exit>"
