--[[
Use these values to initialise the jellybeans variables
]]--

noOfJellybeans = 10
easyMinDeposit = 1
mediumMinDeposit = 6
hardMinDeposit = 11
easyMaxDeposit = 5
mediumMaxDeposit = 10
hardMaxDeposit = 15
