--[[
Use these values to initialise the Data's Infomations
]]--

ifNew = 1
heroPositionX = 400
heroPositionY = 300
heroAnimationDir = 1
noOfJellybeans = 10
heroMapOffsetX = 68
heroMapOffsetY = 222
