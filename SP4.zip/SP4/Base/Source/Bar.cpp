#include "Bar.h"


Bar::Bar()
{
}


Bar::~Bar()
{
}
