#include "FSM.h"


CFSM::CFSM()
{

}

CFSM::~CFSM()
{

}

void CFSM::setState(CFSM::STATES state)
{
	this->state = state;
}

CFSM::STATES CFSM::getState()
{
	return state;
}