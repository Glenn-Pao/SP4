#pragma once
#include "UIFeature.h"

class Bar : public UIFeature
{
public:
	Bar();
	~Bar();
};

