WASD - move forward, left, backward, right
QE - rotate left/right
space - jump 
tab - switch side
left shift - aiming

move mouse - rotate around avatar
left click - shoot cannon
right click - shoot laser